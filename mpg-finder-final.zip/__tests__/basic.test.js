// Placeholder test. Replace with real tests as you add functionality.
test('sanity', () => {
  expect(1 + 1).toBe(2);
});
